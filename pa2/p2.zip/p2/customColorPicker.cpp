#include <stdlib.h>
#include "customColorPicker.h"

customColorPicker::customColorPicker(HSLAPixel fadeColor1,
                                         HSLAPixel fadeColor2, int radius,
                                         int centerX, int centerY)
    : cx(centerX),
      cy(centerY),
      r(radius),
      color1(fadeColor1),
      color2(fadeColor2)
{

}

HSLAPixel customColorPicker::operator()(int x, int y)
{
    HSLAPixel color ;
    double d = sqrt(pow((x - cx),2) + pow((y - cy),2));
    if (color2.h > color1.h && (color2.h - color1.h) < 200) {
        color.h = color1.h + (d / r) * (color2.h - color1.h);
    } else if (color2.h > color1.h && (color2.h - color1.h >= 200)) {
        color.h = color1.h - (d / r) * (360 - color2.h + color1.h);
    } else if (color1.h > color2.h && (color1.h - color2.h < 200)) {
        color.h = color1.h - (d / r) * (color1.h - color2.h);
    } else {
        color.h = color1.h + (d / r) * (360 - color1.h + color2.h);

    }

    if (x % 5 == 0 || y % 5 == 0) {
        color.h +=100;
        color.l = 0.3;
    }

    if (color.h > 360) {
        color.h -= 360;
    }
    if (color.h < 0) {
        color.h += 360;
    }

    color.l = 0.5;
    color.s =1;

    return color;
}
