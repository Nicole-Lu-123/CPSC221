#include "stripeColorPicker.h"

stripeColorPicker::stripeColorPicker(HSLAPixel fillColor, int stripeSpacing)
{
color = fillColor;
spacing = stripeSpacing;
}

HSLAPixel stripeColorPicker::operator()(int x, int y)
{
    HSLAPixel white;
    white.l = 1;
    white.h = 0;
    white.s = 0;

if ( x % spacing == 0 ) 
    return color;
    else 
    return white;


}
