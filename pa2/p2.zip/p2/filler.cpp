/**
 * @file filler.cpp
 * Implementation of functions in the filler namespace. 
 *
 */
#include "filler.h"
// #include "customColorPicker.h"

animation filler::fillStripeDFS(PNG &img, int x, int y, HSLAPixel fillColor,
                                int stripeSpacing, double tolerance, int frameFreq)
{
   /**
     * @todo Your code here! 
     */
   stripeColorPicker a(fillColor, stripeSpacing);
   return fill<Stack>(img, x, y, a, tolerance, frameFreq);
}


animation filler::fillBorderDFS(PNG &img, int x, int y,
                                HSLAPixel borderColor, double tolerance, int frameFreq)
{
   HSLAPixel curr = *img.getPixel(x, y);
   borderColorPicker a(borderColor, img, tolerance, curr);
   return fill<Stack>(img, x, y, a, tolerance, frameFreq);
}

/* Given implementation of a DFS rainbow fill. */
animation filler::fillRainDFS(PNG &img, int x, int y,
                              long double freq, double tolerance, int frameFreq)
{
   rainbowColorPicker a(freq);
   return fill<Stack>(img, x, y, a, tolerance, frameFreq);
}


animation filler::fillStripeBFS(PNG &img, int x, int y, HSLAPixel fillColor,
                                int stripeSpacing, double tolerance, int frameFreq)
{
   stripeColorPicker a(fillColor, stripeSpacing);
   return fill<Queue>(img, x, y, a, tolerance, frameFreq); /**
     * @todo Your code here! 
     */
}

animation filler::fillBorderBFS(PNG &img, int x, int y,
                                HSLAPixel borderColor, double tolerance, int frameFreq)
{
   HSLAPixel curr = *img.getPixel(x, y);
   borderColorPicker a(borderColor, img, tolerance, curr);
   return fill<Queue>(img, x, y, a, tolerance, frameFreq);
}

/* Given implementation of a BFS rainbow fill. */
animation filler::fillRainBFS(PNG &img, int x, int y,
                              long double freq, double tolerance, int frameFreq)
{
   rainbowColorPicker a(freq);
   return fill<Queue>(img, x, y, a, tolerance, frameFreq);
}




// animation filler::fillCustomBFS(PNG& img, int x, int y,
//                                HSLAPixel fadeColor1, HSLAPixel fadeColor2,
//                                int radius, double tolerance, int frameFreq)
// {
//    customColorPicker a(fadeColor1,fadeColor2,radius,x,y);
//    return fill<Queue>(img, x, y, a, tolerance, frameFreq);
// }

// animation filler::fillCustomDFS(PNG& img, int x, int y,
//                                HSLAPixel fadeColor1, HSLAPixel fadeColor2,
//                                int radius, double tolerance, int frameFreq)
// {
//    customColorPicker a(fadeColor1,fadeColor2,radius,x,y);
//    return fill<Stack>(img, x, y, a, tolerance, frameFreq);
// }





template <template <class T> class OrderingStructure>
animation filler::fill(PNG &img, int x, int y, colorPicker &fillColor,
                       double tolerance, int frameFreq)
{

   animation anim;

   const HSLAPixel origin = *img.getPixel(x, y);

   OrderingStructure<int> Xpoints;
   OrderingStructure<int> Ypoints;

   Xpoints.add(x);
   Ypoints.add(y);
   *img.getPixel(x, y) = fillColor(x, y);

   bool **processed = new bool *[img.width()];
   for (int i = 0; i < img.width(); i++)
   {
      processed[i] = new bool[img.height()];
      for (int j = 0; j < img.height(); j++)
      {
         processed[i][j] = false;
      }
   }
   processed[x][y] = true;
   int count = 1;
   if ((count % frameFreq) == 0)
   {
      anim.addFrame(img);
   }

   while (!Xpoints.isEmpty() && !Ypoints.isEmpty())
   {
      int currX = Xpoints.remove();
      int currY = Ypoints.remove();
      if (currX + 1 < img.width() && currY - 1 >= 0 && !processed[currX + 1][currY - 1] && (*img.getPixel(currX + 1, currY - 1)).dist(origin) <= tolerance)
      {
         Xpoints.add(currX + 1);
         Ypoints.add(currY - 1);
         HSLAPixel *p = img.getPixel(currX + 1, currY - 1);
         *p = fillColor(currX + 1, currY - 1);
         count++;
         processed[currX + 1][currY - 1] = true;
         if (count % frameFreq == 0)
         {
            anim.addFrame(img);
         }
      }
      if (currY - 1 >= 0 && !processed[currX][currY - 1] && (*img.getPixel(currX, currY - 1)).dist(origin) <= tolerance)
      {
         Xpoints.add(currX);
         Ypoints.add(currY - 1);
         HSLAPixel *p = img.getPixel(currX, currY - 1);
         *p = fillColor(currX, currY - 1);
         processed[currX][currY - 1] = true;
         count++;
         if (count % frameFreq == 0)
         {
            anim.addFrame(img);
         }
      }

      if (currX - 1 >= 0 && currY - 1 >= 0 && !processed[currX - 1][currY - 1] && (*img.getPixel(currX - 1, currY - 1)).dist(origin) <= tolerance)
      {
         Xpoints.add(currX - 1);
         Ypoints.add(currY - 1);
         HSLAPixel *p = img.getPixel(currX - 1, currY - 1);
         *p = fillColor(currX - 1, currY - 1);
         processed[currX - 1][currY - 1] = true;
         count++;
         if (count % frameFreq == 0)
         {
            anim.addFrame(img);
         }
      }

      if (currX - 1 >= 0 && !processed[currX - 1][currY] && (*img.getPixel(currX - 1, currY)).dist(origin) <= tolerance)
      {
         Xpoints.add(currX - 1);
         Ypoints.add(currY);
         HSLAPixel *p = img.getPixel(currX - 1, currY);
         *p = fillColor(currX - 1, currY);
         processed[currX - 1][currY] = true;
         count++;
         if (count % frameFreq == 0)
         {
            anim.addFrame(img);
         }
      }

      if (currX - 1 >= 0 && currY + 1 < img.height() && !processed[currX - 1][currY + 1] && (*img.getPixel(currX - 1, currY + 1)).dist(origin) <= tolerance)
      {
         Xpoints.add(currX - 1);
         Ypoints.add(currY + 1);
         HSLAPixel *p = img.getPixel(currX - 1, currY + 1);
         *p = fillColor(currX - 1, currY + 1);
         processed[currX - 1][currY + 1] = true;
         count++;
         if (count % frameFreq == 0)
         {
            anim.addFrame(img);
         }
      }

      if (currY + 1 < img.height() && !processed[currX][currY + 1] && (*img.getPixel(currX, currY + 1)).dist(origin) <= tolerance)
      {
         Xpoints.add(currX);
         Ypoints.add(currY + 1);
         HSLAPixel *p = img.getPixel(currX, currY + 1);
         *p = fillColor(currX, currY + 1);
         processed[currX][currY + 1] = true;
         count++;
         if (count % frameFreq == 0)
         {
            anim.addFrame(img);
         }
      }

      if (currX + 1 < img.width() && currY + 1 < img.height() && !processed[currX + 1][currY + 1] && (*img.getPixel(currX + 1, currY + 1)).dist(origin) <= tolerance)
      {
         Xpoints.add(currX + 1);
         Ypoints.add(currY + 1);
         HSLAPixel *p = img.getPixel(currX + 1, currY + 1);
         *p = fillColor(currX + 1, currY + 1);
         processed[currX + 1][currY + 1] = true;
         count++;
         if (count % frameFreq == 0)
         {
            anim.addFrame(img);
         }
      }

      if (currX + 1 < img.width() && !processed[currX + 1][currY] && (*img.getPixel(currX + 1, currY)).dist(origin) <= tolerance)
      {
         Xpoints.add(currX + 1);
         Ypoints.add(currY);
         HSLAPixel *p = img.getPixel(currX + 1, currY);
         *p = fillColor(currX + 1, currY);
         processed[currX + 1][currY] = true;
         count++;
         if (count % frameFreq == 0)
         {
            anim.addFrame(img);
         }
      }
   }
   
   anim.addFrame(img);
for (int k = 0; k < img.width(); k++) {
		delete[] processed[k];
	}
	delete[] processed;

   return anim;
}
