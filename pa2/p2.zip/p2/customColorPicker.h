
#ifndef CUSTOMCOLORPICKER_H
#define CUSTOMCOLORPICKER_H

#include "colorPicker.h"
#include <math.h>
#include <iostream>


class customColorPicker : public colorPicker
{
  public:

    customColorPicker(HSLAPixel fadeColor1, HSLAPixel fadeColor2, int radius,
                        int centerX, int centerY);

    virtual HSLAPixel operator()(int x, int y);

  private:

    int cx, cy, r;
    HSLAPixel color1, color2;
};

#endif
